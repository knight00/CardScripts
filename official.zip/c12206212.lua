--ハーピィ・レディ三姉妹
local s,id=GetID()
function s.initial_effect(c)
	c:EnableReviveLimit()
end
